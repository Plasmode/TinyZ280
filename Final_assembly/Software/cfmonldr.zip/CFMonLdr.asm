; This is the cold bootstrap the load the CF copying program to 0x1000 and run
	org 0
	ld hl,1000h	; point to the load address of bootstrap
          ld (hl),16h
	inc hl
	ld (hl),02h
	inc hl
          ld (hl),21h
	inc hl
	ld (hl),0h
	inc hl
	ld (hl),08h
	inc hl
          ld (hl),0eh
	inc hl
	ld (hl),0c0h
	inc hl
          ld (hl),3eh
	inc hl
	ld (hl),1h
	inc hl	
          ld (hl),0d3h
	inc hl
	ld (hl),0c5h
	inc hl	
          ld (hl),7ah
	inc hl
	ld (hl),0feh
	inc hl	
          ld (hl),04h
	inc hl
	ld (hl),0cah
	inc hl
          ld (hl),0h
	inc hl
	ld (hl),08h
	inc hl
          ld (hl),0d3h
	inc hl
	ld (hl),0c7h
	inc hl
          ld (hl),3eh
	inc hl
	ld (hl),20h
	inc hl	
          ld (hl),0d3h
	inc hl
	ld (hl),0cfh
	inc hl
	ld (hl),0dbh
	inc hl
	ld (hl),0cfh
	inc hl
          ld (hl),0e6h
	inc hl
	ld (hl),8h
	inc hl		
          ld (hl),0cah
	inc hl
	ld (hl),17h
	inc hl
          ld (hl),10h
	inc hl
	ld (hl),6h
	inc hl
          ld (hl),0h
	inc hl
	ld (hl),0edh
	inc hl
          ld (hl),92h
	inc hl
	ld (hl),0dbh
	inc hl	
          ld (hl),0cfh
	inc hl
	ld (hl),14h
	inc hl	
          ld (hl),0c3h
	inc hl
	ld (hl),7h
	inc hl		
          ld (hl),10h

	jp 1000h		; start program execution at 0x1000
	
;                             A       12 	org 1000h
;                             A       13 ;	ld sp,0FFFFh	; initialize stack
;00001000 16 02               A       14 	ld d,2		; points to sector to read
;00001002 21 00 08            A       15 	ld hl,800h	; store CF data starting from 800h
;00001005 0E C0               A       16 	ld c,CFdata	; reg C points to CF data reg
;00001007                     A       17 moresect:
;00001007 3E 01               A       18 	ld a,1		; read 1 sector
;00001009 D3 C5               A       19 	out (CFsectcnt),a	; write to sector count with 1
;0000100B 7A                  A       20 	ld a,d		; read sector pointed by reg D
;0000100C FE 04               A       21 	cp 4		; read sector 2 & 3 only
;0000100E CA 00 08            A       22 	jp z,800h		; load completed, run program
;00001011 D3 C7               A       23 	out (CF07),a	; read the sector pointed by reg D		
;                             A       24 ; no need to setup track, it is setup by CFinit state machine
;                             A       25 ;	xor a		; clear reg A
;                             A       26 ;	out (CF1623),a	; track 0
;                             A       27 ;	out (CF815),a
;00001013 3E 20               A       28 	ld a,20h		; read sector command
;00001015 D3 CF               A       29 	out (CFstat),a	; issue the read sector command
;00001017                     A       30 readdrq:
;00001017 DB CF               A       31 	in a,(CFstat)	; check data request bit set before read CF data
;00001019 E6 08               A       32 	and 8		; bit 3 is DRQ, wait for it to set
;0000101B CA 17 10            A       33 	jp z,readdrq
;                             A       34 
;0000101E 06 00               A       35 	ld b,0h		; sector has 256 16-bit data
;00001020 ED 92               A       36 	db 0edh,92h	; op code for inirw input word and increment
;                             A       37 ;	inirw		; reg HL and c are already setup at the top
;00001022 DB CF               A       38 	in a,(CFstat)	; OUTJMP bug fix
;00001024 14                  A       39 	inc d
;00001025 C3 07 10            A       40 	jp moresect
	db 0,0,0,0,0,0,0,0,0,0,0,0,0,0
	db 0
						
