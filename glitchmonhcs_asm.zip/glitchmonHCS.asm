;1/24/18 Modified for TinyZ280
;Glitch Works Monitor for 8080/8085/Z80 and Compatibles 
;Version 0.1 Copyright (c) 2012 Jonathan Chapman
;http://www.glitchwrks.com
;
;See LICENSE included in the project root for licensing
;information.
;
;*** STOP! THIS CODE WILL NOT RUN BY ITSELF! ***
;
;This is the base monitor. Consult README for information
;on including the I/O module specific to your system.
UARTconf 	equ 10h		  ; UART configuration register
RxData  	equ 16h        ; on-chip UART receive register
TxData  	equ 18h        ; on-chip UART transmit register
RxStat  	equ 14h        ; on-chip UART transmitter status/control register
TxStat  	equ 12h        ; 0n-chip UART receiver status/control register

    	ORG 200H               ;See README for more info
	jp start
pageio:	db 0		; page i/o register for 'I' and 'O' commands
;Initialization and sign-on message
start:
	ld sp,0ffffh		; initialize stack
	ld c,08h				; reg c points to I/O page register
	ld l,0feh			; set I/O page register to 0xFE
	db 0edh,6eh			; this is the op code for LDCTL (C),HL
;	ldctl (c),hl		; write to I/O page register
	ld a,0e2h			; initialize the UART configuration register
	out (UARTconf),a
	ld a,80h				;enable UART transmit and receive
	out (TxStat),a
	out (RxStat),a
	nop
	nop
SE1:    	LD HL, LOGMSG$
        	CALL STROUT
        	LD HL, MSG$
        	CALL STROUT

;Main command loop
CMDLP:  	LD HL, PROMPT$
        	CALL STROUT
        	CALL CIN
        	AND 5Fh
        	CP A,'D'
        	JP Z,MEMDMP
        	CP A,'E'
        	JP Z,EDMEM
        	CP A,'G'
        	JP Z,GO
        	CP A,'O'
        	JP Z,OUTPUT
        	CP A,'I'
        	JP Z,INPUT
	cp a,'P'			; display and change page I/O reg
	jp z,pageio	
        	LD HL, ERR$
        	CALL STROUT
        	JP CMDLP

;Get a port address, write byte out
; port address is 24 bits, but bit 8-15 are 'don't care'
OUTPUT: 	
	CALL SPCOUT
        	CALL GETHEX	; get addr 16-23
        	LD B,A
	ld a,'x'		; put out two 'x' to denote addr 8-15 are 'don't care'
	call cout
	ld a,'x'
	call cout
	call GETHEX	; get addr 0-7
        	CALL SPCOUT
        	CALL GETHEX
        	CALL JMPOUT
        	JP CMDLP

;Input from port, print contents
INPUT:  	
	CALL SPCOUT
        	CALL GETHEX
        	LD B,A
        	CALL SPCOUT
        	LD A,B
        	CALL JMPIN
        	CALL HEXOUT
        	JP CMDLP

; Display & Change page I/O register
;
pageio:
	push bc		; save register BC, HL
	push hl		; 
	call SPCOUT	; insert a space after 'p' command
	ld c,8		; point to Page I/O reg
	db 0edh,66h	; opcode for ldctl hl,(c)
;	ldctl hl,(c)	; read the page i/o reg
	ld a,l		; get page i/o reg value in reg A
	call HEXOUT
	call SPCOUT	; space deliminter
	call GETHEX	; get a different value
	ld l,a		; transfer value to reg HL
	db 0edh,6eh	; opcode for ldctl (c),hl
;	ldctl (c),hl	; write the page i/o reg
	call SPCOUT	; delimiter

	pop hl		; restore reg BC, HL
	pop bc
	jp CMDLP

;Edit memory from a starting address until X is
;pressed. Display mem loc, contents, and results
;of write.
EDMEM:  	CALL SPCOUT
        	CALL ADRIN
        	LD H,D
        	LD L,E
ED1:    	LD A,13
        	CALL COUT
        	LD A,10
        	CALL COUT
        	CALL ADROUT
        	CALL SPCOUT
        	LD A,':'
        	CALL COUT
        	CALL SPCOUT
        	CALL DMPLOC
        	CALL SPCOUT
        	CALL GETHEX
        	JP C,CMDLP
        	LD (HL),A
        	CALL SPCOUT
        	CALL DMPLOC
        	INC HL
        	JP ED1

;Get an address and jump to it
GO:     	CALL SPCOUT
        	CALL ADRIN
        	LD H,D
        	LD L,E
        	JP (HL)

;Dump memory between two address locations
MEMDMP: 	CALL SPCOUT
        	CALL ADRIN
        	LD H,D
        	LD L,E
        	LD C,10h
        	CALL SPCOUT
        	CALL ADRIN
MD1:    	LD A,13
        	CALL COUT
        	LD A,10
        	CALL COUT
        	CALL DMP16
        	LD A,D
        	CP H
        	JP M,CMDLP
        	LD A,E
        	CP L
        	JP M,MD2
        	JP MD1
MD2:    	LD A,D
        	CP H
        	JP NZ,MD1
        	JP CMDLP

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;DMP16 -- Dump 16 consecutive memory locations
;
;pre: HL pair contains starting memory address
;post: memory from HL to HL + 16 printed
;post: HL incremented to HL + 16
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
DMP16:  	CALL ADROUT
        	CALL SPCOUT
        	LD A,':'
        	CALL COUT
        	LD C,10h
DM1:    	CALL SPCOUT
        	CALL DMPLOC
        	INC HL			; bug fix, HCS
        	DEC C
        	RET Z
        	JP DM1

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;DMPLOC -- Print a byte at HL to console
;
;pre: HL pair contains address of byte
;post: byte at HL printed to console
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
DMPLOC: 	LD A,(HL)
        	CALL HEXOUT
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;HEXOUT -- Output byte to console as hex
;
;pre: A register contains byte to be output
;post: byte is output to console as hex
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
HEXOUT: 	PUSH BC
        	LD B,A
        	RRCA
        	RRCA
        	RRCA
        	RRCA
        	AND 0Fh
        	CALL HEXASC
        	CALL COUT
        	LD A,B
        	AND 0Fh
        	CALL HEXASC
        	CALL COUT
        	POP BC
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;HEXASC -- Convert nybble to ASCII char
;
;pre: A register contains nybble
;post: A register contains ASCII char
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
HEXASC: 	ADD 90h
        	DAA
        	ADC A,40h
        	DAA
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;ADROUT -- Print an address to the console
;
;pre: HL pair contains address to print
;post: HL printed to console as hex
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
ADROUT: 	LD A,H
        	CALL HEXOUT
        	LD A,L
        	CALL HEXOUT
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;ADRIN -- Get an address word from console
;
;pre: none
;post: DE contains address from console
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
ADRIN:  	CALL GETHEX
        	LD D,A
        	CALL GETHEX
        	LD E,A
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;GETHEX -- Get byte from console as hex
;
;pre: none
;post: A register contains byte from hex input
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
GETHEX: 	PUSH DE
        	CALL CIN
        	CP 'X'
        	JP Z,GE2
	cp 'x'		; exit with lower 'x'
	jp z,GE2
        	CALL ASCHEX
        	RLCA
        	RLCA
        	RLCA
        	RLCA
        	LD D,A
        	CALL CIN
        	CALL ASCHEX
        	OR D
GE1:    	POP DE
        	RET
GE2:    	SCF
        	JP GE1

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;ASCHEX -- Convert ASCII coded hex to nybble
;
;pre: A register contains ASCII coded nybble
;post: A register contains nybble
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
ASCHEX: 	SUB 30h
        	CP 0Ah
        	RET M
        	AND 5Fh
        	SUB 07h
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;JMPOUT -- Output to a dynamic port
;
;pre: B register contains the port to output to
;pre: A register contains the byte to output
;post: byte is output
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
JMPOUT: 	LD C,0D3h
        	CALL GOBYT
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;JMPIN -- Input from a dynamic port
;
;pre: A register contains the port to input from
;post: A register contains port value
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
JMPIN:  	LD C,0DBh
        	LD B,A
        	CALL GOBYT
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;GOBYT -- Push a two-byte instruction and RET
;         and jump to it
;
;pre: B register contains operand
;pre: C register contains opcode
;post: code executed, returns to caller
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
GOBYT:  	LD HL,0000
        	ADD HL,SP
        	DEC HL
        	LD (HL),0C9h
        	DEC HL
        	LD (HL),B
        	DEC HL
        	LD (HL),C
        	JP (HL)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;SPCOUT -- Print a space to the console
;
;pre: none
;post: 0x20 printed to console
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
SPCOUT: 	LD A,' '
        	CALL COUT
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;STROUT -- Print a null-terminated string
;
;pre: HL contains pointer to start of a null-
;     terminated string
;post: string at HL printed to console
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
STROUT: 	LD A,(HL)
        	CP 00
        	RET Z
        	CALL COUT
        	INC HL
        	JP STROUT

LOGMSG$:	db "Glitch Works Monitor for 8080/8085/Z80 and Compatible", 13, 10
        	db "Version 0.1 Copyright (c) 2012 Jonathan Chapman",13,10 
		  db "1/24/18 Modified by Bill Shen for TinyZ280",0
PROMPT$:	db 13, 10, 10, ">", 0
ERR$:   	db 13, 10, "ERROR", 0

;Glitch Works Monitor I/O Module for Z280
;
;Adjust CTLPRT and DATPRT for your specific hardware.
;Stack Pointer initialized at 0xFFFF, adjust as needed.
;
;After including this module, you still need to
;set the ORG in the main monitor source. If it is to
;be burned to ROM for the 8085 SBC, you want 0x0000

RxData  	equ 16h        ;;Z on-chip UART receive register
TxData  	equ 18h        ;;Z on-chip UART transmit register
RxStat  	equ 14h        ;;Z on-chip UART transmitter status/control register
TxStat  	equ 12h        ;;Z 0n-chip UART receiver status/control register

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;CIN -- Get a char from the console and echo
;
;pre: console device is initialized
;post: received char is in A register
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
CIN:    
        	IN A,(RxStat)		;;Z read on-chip UART receive status
        	AND 10H				;;Z data available?
        	JP Z,CIN
        	IN A,(RxData)		;;Z save to reg A
        	OUT (TxData),A		;;Z echo back
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;COUT -- Output a character to the console
;
;pre: A register contains char to be printed
;post: character is printed to the console
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
COUT:   

	EX AF,AF'				;;Z save data to be printed to alternate bank
COUT1:  	IN A,(TxStat)		;;Z transmit empty?
        	AND 01H
        	JP Z,COUT1
	EX AF,AF'				;;Z restore data to be printed
        	OUT (TxData),A		;;Z write it out
        	RET

;Init string for the SCC, 9600 baud
;INISCC$:  db 04H, 44H, 03H, 0C1H, 05H, 0EAH, 0BH, 56H, 0CH, 0EH, 0DH, 00H, 0EH, 01H, 0FH, 00H

;I/O Module description string
MSG$:     db 13, 10, "Built for Zilog Z280", 0

